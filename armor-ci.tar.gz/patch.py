"""把 armor 的 4 个新文件接进 RikkaHub 的现有代码。

在仓库根目录执行：python3 patch.py
每一处替换都断言「原文出现次数 == 1」，匹配不上就退出，不会把代码改坏。
"""
import pathlib
import sys

TF = "app/src/main/java/me/rerere/rikkahub/data/ai/transformers/Transformer.kt"
CF = "app/src/main/java/me/rerere/rikkahub/data/ai/ChatRequestFactory.kt"
CS = "app/src/main/java/me/rerere/rikkahub/service/ChatService.kt"


def patch(path, old, new, count=1):
    p = pathlib.Path(path)
    text = p.read_text(encoding="utf-8")
    got = text.count(old)
    if got != count:
        print(f"FAIL {path}: expected {count} occurrence(s), got {got}", file=sys.stderr)
        sys.exit(1)
    p.write_text(text.replace(old, new), encoding="utf-8")
    print(f"OK   {path}")


# ---------- Transformer.kt：给 TransformerContext 加 conversationId ----------
patch(
    TF,
    "import android.content.Context\n",
    "import android.content.Context\nimport kotlin.uuid.Uuid\n",
)
patch(
    TF,
    "    val workspaceCwd: String? = null,\n",
    "    val workspaceCwd: String? = null,\n    val conversationId: Uuid? = null,\n",
)
patch(
    TF,
    "    workspaceCwd: String? = null,\n",
    "    workspaceCwd: String? = null,\n    conversationId: Uuid? = null,\n",
)
patch(
    TF,
    "        workspaceCwd = workspaceCwd,\n",
    "        workspaceCwd = workspaceCwd,\n        conversationId = conversationId,\n",
)

# ---------- ChatRequestFactory.kt：挂 ArmorTransformer + 透传 conversationId ----------
patch(
    CF,
    "import me.rerere.rikkahub.data.ai.prompts.buildMemoryPrompt\n",
    "import me.rerere.rikkahub.data.ai.armor.ArmorTransformer\n"
    "import me.rerere.rikkahub.data.ai.prompts.buildMemoryPrompt\n",
)
patch(
    CF,
    "        WorkspaceReminderTransformer(workspaceRepository),\n",
    "        WorkspaceReminderTransformer(workspaceRepository),\n        ArmorTransformer,\n",
)
patch(
    CF,
    "            workspaceCwd = turn.workspaceCwd,\n",
    "            workspaceCwd = turn.workspaceCwd,\n            conversationId = turn.conversationId,\n",
)

# ---------- ChatService.kt：把 provider 包一层 ArmorProvider ----------
patch(
    CS,
    "import me.rerere.rikkahub.data.ai.TranslationHandler\n",
    "import me.rerere.rikkahub.data.ai.TranslationHandler\n"
    "import me.rerere.rikkahub.data.ai.armor.ArmorProvider\n"
    "import me.rerere.rikkahub.data.ai.armor.ArmorRegistry\n",
)
patch(
    CS,
    "            val (request, hooks) = requestFactory.createAgent(turn, history, session.processingStatus)\n",
    "            val (baseRequest, hooks) = requestFactory.createAgent(turn, history, session.processingStatus)\n"
    "            val request = baseRequest.copy(\n"
    "                provider = ArmorProvider(baseRequest.provider, ArmorRegistry.state, turn.conversationId),\n"
    "            )\n",
)

print("all patches applied")
