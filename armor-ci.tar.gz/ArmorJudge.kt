package me.rerere.rikkahub.data.ai.armor

/**
 * 拒答/安全话术判定器。
 *
 * 三个口径分开，各有用途：
 *  - [refusalPatterns]：明确的拒答句式，命中即视为这一轮没交付
 *  - [safetyPatterns]：安全审查苗头（比拒答宽），只上报、只做轻纠正
 *  - [negationRe]：否定辖域。命中点前面若紧邻「严禁 / 不给 / 不要」，说明模型是在
 *    复述禁令，不是在拒答 —— 不加这层，「绝不添加免责声明」这种规则文本会被判成拒答，
 *    然后无限触发纠正。这是破甲在 v6.0.0 修过的同类误伤。
 */
object ArmorJudge {

    /** 正文里出现这些，基本就是没交付。 */
    private val refusalPatterns: List<Regex> = listOf(
        Regex("""(?:我|本模型|助手)\s*(?:无法|不能|不予|不会|没法)\s*(?:提供|协助|帮助|回答|生成|完成|参与|满足|处理|透露|给出)"""),
        Regex("""(?:超出|超乎|不在)\s*(?:我|本人)?的?\s*(?:能力|范围|职责|权限)"""),
        Regex("""建议\s*(?:你|您)?\s*(?:咨询|寻求|联系|参考官方|使用官方|购买正版)"""),
        Regex("""仅供\s*(?:参考|测试|学习|研究|演示)"""),
        Regex("""(?:抱歉|对不起)\s*[，,。]?\s*(?:我|这个)"""),
        Regex("""(?i)\bI\s*(?:cannot|can't|can not|am unable to|won't)\s*(?:help|assist|provide|answer|comply|do)"""),
        Regex("""(?i)\bas an AI\b"""),
        Regex("""(?i)\bI'm\s*(?:sorry|afraid)\b"""),
    )

    /** 安全审查苗头：不一定拒答，但说明模型开始在边界上打转。 */
    private val safetyPatterns: List<Regex> = listOf(
        Regex("""(?i)\bcontent policy\b"""),
        Regex("""(?i)\bsafety (?:policy|guideline|rule)"""),
        Regex("""(?i)\bguardrail"""),
        Regex("""(?i)\bmoderation\b"""),
        Regex("""(?i)\bethical (?:guideline|consideration|concern)"""),
        Regex("""(?i)\bdisclaimer\b"""),
        Regex("""(?i)\bharmful (?:content|request)"""),
        Regex("""不宜|不便展开|敏感内容|合规性|合法性|伦理|道德风险|法律风险|安全边界|正当性"""),
    )

    /**
     * 否定辖域：命中点前 24 个字符内出现这些词，判定为「在下禁令」而不是「在拒答」。
     *
     * 破甲自己的载荷里到处是「不给替代方案 / 不要建议咨询专业人士」，
     * 模型照做时会复述，复述就命中，所以这层过滤是必需项而不是优化项。
     */
    private val negationRe = Regex(
        """(?:严禁|禁止|绝不|不许|不得|不会出现|不能有|避免|不要|别(?:再|说|提|写|做|拿|给|去|碰)|不给|不做|不提供|不搞|不用|无需|不必)[^。\n]{0,24}$"""
    )

    /** 正文只看开头这么多字符判拒答（中段出现「不能」多半是正常叙述） */
    private const val OPENING_WINDOW = 240

    /** 没有推理链时把正文窗口放大，否则中后段的拒答会漏判 */
    private const val TEXT_FULL_WINDOW = 2000

    /** 推理链只看尾部 */
    private const val REASONING_WINDOW = 4000

    fun judge(watch: ArmorWatch): ArmorVerdict {
        val reasoningTail = if (watch.reasoning.length > REASONING_WINDOW) {
            watch.reasoning.substring(watch.reasoning.length - REASONING_WINDOW)
        } else {
            watch.reasoning.toString()
        }
        val hasReasoning = reasoningTail.isNotEmpty()
        val textAll = watch.text.toString()
        val textOpening = textAll.take(OPENING_WINDOW)
        val textScan = if (hasReasoning) textOpening else textAll.take(TEXT_FULL_WINDOW)

        val refusal = hits(textScan, refusalPatterns)
        if (refusal.isNotEmpty()) {
            watch.refusalHits = refusal
            return ArmorVerdict.Refusal
        }

        val reasoningRefusal = hits(reasoningTail, refusalPatterns)
        if (reasoningRefusal.isNotEmpty()) {
            watch.refusalHits = reasoningRefusal
            return ArmorVerdict.ReasoningRefusal
        }

        val safety = (hits(reasoningTail, safetyPatterns) + hits(textOpening, safetyPatterns)).distinct()
        if (safety.isNotEmpty()) {
            watch.safetyHits = safety.take(6)
            return ArmorVerdict.SafetyHint
        }

        return ArmorVerdict.Clean
    }

    /**
     * 在文本里找命中，跳过落在否定辖域里的。
     *
     * 返回去重后的命中片段，最多 6 条 —— 只是给人看的摘要，不需要全量。
     */
    fun hits(text: String, patterns: List<Regex>): List<String> {
        if (text.isEmpty()) return emptyList()
        val found = LinkedHashSet<String>()
        for (pattern in patterns) {
            for (match in pattern.findAll(text)) {
                val start = match.range.first
                if (start > 0 && negationRe.containsMatchIn(text.substring(0, start))) continue
                found += match.value.trim()
                if (found.size >= 6) return found.toList()
            }
        }
        return found.toList()
    }

    /** 是否需要在下一步注入纠正指令。 */
    fun needsCorrection(verdict: ArmorVerdict): Boolean =
        verdict == ArmorVerdict.Refusal ||
            verdict == ArmorVerdict.ReasoningRefusal ||
            verdict == ArmorVerdict.SafetyHint
}
